<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/users/{user}/{type}','UserController@showPublished');

Route::get('/users/{user}','MessageController@create');
Route::get('/setting','UserController@showSetting');
Route::post('/setting','UserController@saveSetting');

Route::post('messages/{user}','MessageController@store');

Route::get('home/messages','MessageController@showMessages');
Route::get('home/questions','MessageController@showQuestions');





Route::post('publish/{message}','MessageController@publish');

Route::get('/logout','UserController@logout');



Route::get('/test',function(){

    $p = password_hash('mostafa',PASSWORD_DEFAULT);
    dd(password_verify('mostafa',$p));
});

Route::get('/oauth/{provider}','Auth\LoginController@socialLogin');

Route::get('/oauth/{provider}/callback','Auth\LoginController@handleSocialCallback');

Route::get('/admin','AdminController@index');
Route::get('/admin/edit/{user}','AdminController@edit');
Route::post('/admin/edit/{user}','AdminController@submitEdit');

Route::get('/user/{user}/delete','UserController@delete');

Route::get('admin/search','AdminController@search');
