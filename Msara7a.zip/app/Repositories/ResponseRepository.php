<?php
/**
 * Created by PhpStorm.
 * User: Mostafa
 * Date: 01/07/2017
 * Time: 05:28 ص
 */

namespace App\Repositories;


class ResponseRepository
{


}