<?php

namespace App\Http\Controllers;

use App\Factories\RequestTypes\Question;
use App\Factories\RequestTypes\TypeFactory;
use App\Repositories\UserRepository;
use App\User;
use Image;
use Illuminate\Http\Request;

class UserController extends Controller
{

    function show(User $user){


        return view('userProfile',compact('user'));
    }

    public function showPublished(User $user,$type){
        $questions = TypeFactory::make($type)->getPublished($user);
        return view('published_questions',compact('questions','user'));
    }

    public function showSetting(){

        return view('setting');

    }

    public function saveSetting(){

        $this->validate(request(),[
            'name' => 'required|unique:users,name,' . auth()->id(),
            'email' => 'required|unique:users,email,'. auth()->id(),
            'profilePicture' => 'image',


        ]);

        $name = auth()->check()?auth()->user()->name:'ahmed';
        if(request()->hasFile('profilePicture')){
            $img= Image::make(request('profilePicture'))->fit(150,150)->save("images/$name.png");
            $imgSrc = $img->dirname . '/' . $img->basename;
            auth()->user()->profile_photo = $imgSrc;

        }
        auth()->user()->name = request('name');
        auth()->user()->email = request('email');
        auth()->user()->facebook = request('facebook');
        auth()->user()->twitter = request('twitter');
        auth()->user()->google_plus = request('google');

        auth()->user()->save();
        return back();
    }


    public function logout(){
        auth()->logout();
        return redirect('home');
    }

    public function delete(User $user){
        $user->forceDelete();

// Force deleting all related models...


        return back();
    }

}
