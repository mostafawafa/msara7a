<?php
/**
 * Created by PhpStorm.
 * User: Mostafa
 * Date: 22/09/2017
 * Time: 03:34 م
 */

namespace App\Factories\SearchTypes;


interface ISearch
{

    public function search();

}