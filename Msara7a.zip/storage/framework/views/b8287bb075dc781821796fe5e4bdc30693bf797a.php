<?php $__env->startSection('main'); ?>
    <section class="questions">
        <div class="container">
            <h1 class="text-center">your url : <a href="/users/<?php echo e(auth()->id()); ?>"> <?php echo e($_SERVER['HTTP_HOST']); ?>/users/<?php echo e(auth()->id()); ?> </a></h1>

            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="panel-info panel text-center">
                            <div class="panel-heading">

                                <?php if(isset($question->sender)): ?>
                                    <a href="/users/<?php echo e($question->sender->id); ?>"><?php echo e($question->sender->name); ?></a>
                                <?php else: ?>
                                    Anon

                                <?php endif; ?>

                            </div>
                            <div class="panel-body">


                            </div>
                            <h1 ><?php echo e($question['body']); ?></h1>
                            <span><?php echo e($question->created_at->diffForHumans()); ?></span>
                            <form action="/publish/<?php echo e($question->id); ?>" class="text-center" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="response">response:</label>
                                    <textarea name='response' class="form-control" rows="5" id="response"><?php echo e(isset($question->response->body) ? $question->response->body : ''); ?></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary text-center">
                                    <?php if($question->published): ?>
                                        unpuplish
                                    <?php else: ?>
                                        puplish
                                    <?php endif; ?>
                                </button>

                            </form>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>


    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>