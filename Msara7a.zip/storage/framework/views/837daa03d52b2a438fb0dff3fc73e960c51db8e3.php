<footer>
    <div class="container">
        <h4 class="text-center">    Copyright 2017-<?php echo e(date('Y')); ?> by Mostafa Abouelwafa. All Rights Reserved.
        </h4>

    </div>
</footer>