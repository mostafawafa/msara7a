<?php $__env->startSection('main'); ?>
    <section class="admin-users">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3 text-center">

                    <form action="admin/search" class="form-inline">
                        SEARCH BY:
                        <div class="radio-inline">
                            <label><input value="name" type="radio" name="type">Name</label>
                        </div>
                        <div class="radio-inline">
                            <label><input value="email" type="radio" name="type">Email</label>
                        </div>
                        <div class="radio-inline ">
                            <label><input  value="username" type="radio" name="type">Username</label>
                        </div>
                        <div class="form-group">

                            <input type="text" name="s" class="form-control">

                        </div>
                        <button type="submit" class="btn btn-default">search</button>



                    </form>
                </div>

            </div>

            <table class="table table-bordered">
                <thead>
                <tr>

                    <th>id</th>
                    <th>name</th>
                    <th>userName</th>
                    <th>Email</th>
                    <th>joined at</th>
                    <th>edit</th>
                    <th>delete</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->user_name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                        <td><a href="/admin/edit/<?php echo e($user['id']); ?>">edit</a></td>
                        <td><a href="user/<?php echo e($user['id']); ?>/delete">delete</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <?php echo e($users->links()); ?>



            </div>
        </div>



    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>