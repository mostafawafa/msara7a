<?php $__env->startSection('main'); ?>

    <section class="setting">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <form class="center-block form-horizontal text-center" action="setting" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label class='control-label col-md-2 col-md-offset-2' for="Name">Name:</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" id="Name" name="name" value="<?php echo e(auth()->user()->name); ?>">
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>

                                <?php endif; ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <label for="Email" class="control-label col-md-2 col-md-offset-2">Email:</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="email" id="Email" value="<?php echo e(auth()->user()->email); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>

                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-2 col-md-offset-2 " for="profilePicture">Upload:</label>
                            <div class="col-md-6">
                                <img class="previous-image pull-left img-thumbnail img-circle" src="<?php echo e(URL::to('/') . '/' . auth()->user()->profile_photo); ?>" alt="previous photo">

                                <input type="file" class="form-control" name="profilePicture" id="profilePicture">
                                <?php if($errors->has('profilePicture')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('profilePicture')); ?></strong>
                                    </span>

                                <?php endif; ?>

                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="Facebook" class="control-label col-md-2 col-md-offset-2">Facebook:</label>
                            <div class="col-md-6">
                                <input type="text"  class="form-control" value="<?php echo e(auth()->user()->facebook); ?>" name="facebook" id="Facebook">
                            </div>
                            <?php if($errors->has('facebook')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('facebook')); ?></strong>
                                    </span>

                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="Twitter" class="control-label col-md-2 col-md-offset-2">Twitter:</label>
                            <div class="col-md-6">
                                <input type="text"  class="form-control" name="twitter" value="<?php echo e(auth()->user()->twitter); ?>" id="Twitter">
                            </div>
                            <?php if($errors->has('twitter')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('twitter')); ?></strong>
                                    </span>

                            <?php endif; ?>
                        </div>
                         <div class="form-group">
                             <label for="googlePlus" class="control-label col-md-2 col-md-offset-2">Google:</label>
                                                     <div class="col-md-6">
                                                         <input type="text"  class="form-control" name="google" value="<?php echo e(auth()->user()->google_plus); ?>" id="googlePlus">
                                                     </div>
                                                     <?php if($errors->has('google')): ?>
                                                         <span class="help-block">
                                                                 <strong><?php echo e($errors->first('google')); ?></strong>
                                                             </span>

                                                     <?php endif; ?>
                                                 </div>
                        <button type="submit" class="btn btn-default">Submit</button>

                    </form>

                </div>

            </div>

        </div>


    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>