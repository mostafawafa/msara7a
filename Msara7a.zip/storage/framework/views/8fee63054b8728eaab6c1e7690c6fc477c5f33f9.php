<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">

            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel-info panel text-center">
                    <div class="panel-heading"><?php echo e(isset($message->sender->name) ? $message->sender->name : 'anon'); ?></div>
                    <div class="panel-body">


                    </div>
                        <h1 ><?php echo e($message['body']); ?></h1>
                    <span><?php echo e($message->created_at->diffForHumans()); ?></span>
                    <form action="/publish/<?php echo e($message->id); ?>" class="text-center" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-primary text-center">
                            <?php if($message->published): ?>
                                unpuplish
                            <?php else: ?>
                                puplish
                            <?php endif; ?>
                        </button>

                    </form>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>